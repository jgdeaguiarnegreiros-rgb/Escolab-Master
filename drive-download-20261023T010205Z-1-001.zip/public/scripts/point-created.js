window.setTimeout(() => {
    window.location.assign("/")
}, 2000)
