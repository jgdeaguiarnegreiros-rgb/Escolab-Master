const ufSelect = document.querySelector('select[name="uf"]')
const citySelect = document.querySelector('select[name="city"]')
const stateInput = document.querySelector('input[name="state"]')
const collectedItems = document.querySelector('input[name="items"]')

async function populateStates() {
    try {
        const response = await fetch("https://servicodados.ibge.gov.br/api/v1/localidades/estados/")
        if (!response.ok) throw new Error("Não foi possível carregar os estados.")

        const states = await response.json()
        for (const state of states) {
            ufSelect.add(new Option(state.nome, state.id))
        }
    } catch {
        ufSelect.disabled = true
        ufSelect.insertAdjacentHTML("afterend", '<p role="alert">Não foi possível carregar os estados. Tente novamente mais tarde.</p>')
    }
}

async function loadCities(event) {
    const selectedOption = event.target.selectedOptions[0]
    const stateId = event.target.value

    stateInput.value = selectedOption ? selectedOption.textContent : ""
    citySelect.replaceChildren(new Option("Selecione a Cidade", ""))
    citySelect.disabled = true

    if (!stateId) return

    try {
        const response = await fetch(
            `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${encodeURIComponent(stateId)}/municipios`,
        )
        if (!response.ok) throw new Error("Não foi possível carregar as cidades.")

        const cities = await response.json()
        for (const city of cities) {
            citySelect.add(new Option(city.nome, city.nome))
        }
        citySelect.disabled = false
    } catch {
        stateInput.value = ""
        citySelect.replaceChildren(new Option("Não foi possível carregar as cidades", ""))
    }
}

ufSelect.addEventListener("change", loadCities)
populateStates()

const selectedItems = new Set()
document.querySelectorAll(".items-grid li[data-id]").forEach((item) => {
    function toggleSelection() {
        const itemId = item.dataset.id

        if (selectedItems.has(itemId)) {
            selectedItems.delete(itemId)
        } else {
            selectedItems.add(itemId)
        }

        item.classList.toggle("selected", selectedItems.has(itemId))
        item.setAttribute("aria-checked", String(selectedItems.has(itemId)))
        collectedItems.value = [...selectedItems].join(",")
    }

    item.addEventListener("click", toggleSelection)
    item.addEventListener("keydown", (event) => {
        if (event.key === " " || event.key === "Enter") {
            event.preventDefault()
            toggleSelection()
        }
    })
})

document.querySelector("form[action='/savepoint']").addEventListener("submit", (event) => {
    if (selectedItems.size === 0) {
        event.preventDefault()
        let message = document.querySelector("#items-error")
        if (!message) {
            message = document.createElement("p")
            message.id = "items-error"
            message.setAttribute("role", "alert")
            message.textContent = "Selecione pelo menos um item de coleta."
            document.querySelector(".items-grid").after(message)
        }
        document.querySelector(".items-grid li")?.focus()
    }
})
