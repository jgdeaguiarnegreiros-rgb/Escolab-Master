const buttonSearch = document.querySelector("#page-home main a")
const modal = document.querySelector("#modal")
const close = document.querySelector("#modal .header a")
const searchInput = document.querySelector("#modal input[name='search']")

function setModalOpen(isOpen) {
    modal.classList.toggle("hide", !isOpen)
    modal.setAttribute("aria-hidden", String(!isOpen))
    if (isOpen) searchInput.focus()
    else buttonSearch.focus()
}

buttonSearch.addEventListener("click", (event) => {
    event.preventDefault()
    setModalOpen(true)
})

close.addEventListener("click", (event) => {
    event.preventDefault()
    setModalOpen(false)
})

modal.addEventListener("click", (event) => {
    if (event.target === modal) setModalOpen(false)
})

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !modal.classList.contains("hide")) {
        setModalOpen(false)
    }
})

modal.addEventListener("keydown", (event) => {
    if (event.key !== "Tab") return

    const focusable = [...modal.querySelectorAll("a[href], input:not(:disabled), button:not(:disabled)")]
    const first = focusable[0]
    const last = focusable[focusable.length - 1]

    if (event.shiftKey && document.activeElement === first) {
        event.preventDefault()
        last.focus()
    } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault()
        first.focus()
    }
})
