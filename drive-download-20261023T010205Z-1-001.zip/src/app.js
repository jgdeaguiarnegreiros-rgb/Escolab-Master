const path = require("node:path")
const express = require("express")
const nunjucks = require("nunjucks")

const MAX_SEARCH_LENGTH = 100
const MAX_FIELD_LENGTH = {
  name: 120,
  image: 2048,
  address: 200,
  address2: 100,
  state: 100,
  city: 100,
}
const ALLOWED_ITEMS = new Set([
  "Lâmpadas",
  "Pilhas e Baterias",
  "Papéis e Papelão",
  "Resíduos Eletrônicos",
  "Resíduos Orgânicos",
  "Óleo de Cozinha",
])

function getText(value) {
  return typeof value === "string" ? value.trim() : ""
}

function isValidImageUrl(value) {
  try {
    const url = new URL(value)
    return url.protocol === "https:"
  } catch {
    return false
  }
}

function createApp(db) {
  const app = express()
  const viewsPath = path.join(__dirname, "views")

  app.disable("x-powered-by")
  app.use((req, res, next) => {
    res.set("X-Content-Type-Options", "nosniff")
    res.set("X-Frame-Options", "SAMEORIGIN")
    res.set("Referrer-Policy", "strict-origin-when-cross-origin")
    res.set(
      "Content-Security-Policy",
      "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'self'; form-action 'self'; img-src 'self' https:; font-src 'self' https://fonts.gstatic.com; style-src 'self' https://fonts.googleapis.com; script-src 'self'; connect-src 'self' https://servicodados.ibge.gov.br",
    )
    next()
  })
  app.use(express.static(path.join(__dirname, "..", "public")))
  app.use(express.urlencoded({ extended: false, limit: "10kb" }))
  nunjucks.configure(viewsPath, {
    autoescape: true,
    express: app,
    noCache: process.env.NODE_ENV !== "production",
    watch: false,
  })

  app.get("/", (req, res) => {
    res.render("index.html", { title: "Seu marketplace de coleta de resíduos" })
  })

  app.get("/create-point", (req, res) => {
    res.render("create-point.html")
  })

  app.post("/savepoint", (req, res) => {
    const place = {
      image: getText(req.body.image),
      name: getText(req.body.name),
      address: getText(req.body.address),
      address2: getText(req.body.address2),
      state: getText(req.body.state),
      city: getText(req.body.city),
      items: getText(req.body.items),
    }
    const invalidField = Object.entries(MAX_FIELD_LENGTH).some(([field, maximum]) =>
      !place[field] || place[field].length > maximum
    )
    const selectedItems = place.items ? place.items.split(",").map((item) => item.trim()) : []
    const invalidItems = selectedItems.length === 0 ||
      selectedItems.some((item) => !ALLOWED_ITEMS.has(item)) ||
      new Set(selectedItems).size !== selectedItems.length

    if (invalidField || !isValidImageUrl(place.image) || invalidItems) {
      return res.status(400).render("create-point.html", {
        error: "Confira os campos obrigatórios e selecione pelo menos um item de coleta válido.",
      })
    }

    const query = `
      INSERT INTO places (image, name, address, address2, state, city, items)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `
    const values = [
      place.image,
      place.name,
      place.address,
      place.address2,
      place.state,
      place.city,
      selectedItems.join(", "),
    ]

    db.run(query, values, (error) => {
      if (error) {
        console.error("Erro ao cadastrar ponto de coleta:", error.message)
        return res.status(500).send("Não foi possível cadastrar o ponto de coleta.")
      }

      return res.render("create-point.html", { saved: true })
    })
  })

  app.get("/search-results", (req, res) => {
    const search = getText(req.query.search)

    if (search.length > MAX_SEARCH_LENGTH) {
      return res.status(400).render("search-results.html", {
        places: [],
        total: 0,
        error: `A pesquisa deve ter no máximo ${MAX_SEARCH_LENGTH} caracteres.`,
      })
    }

    if (!search) {
      return res.render("search-results.html", { places: [], total: 0 })
    }

    db.all(
      "SELECT * FROM places WHERE city LIKE ? COLLATE NOCASE",
      [`%${search}%`],
      (error, places) => {
        if (error) {
          console.error("Erro ao pesquisar pontos de coleta:", error.message)
          return res.status(500).send("Não foi possível pesquisar pontos de coleta.")
        }

        const safePlaces = Array.isArray(places) ? places : []
        return res.render("search-results.html", {
          places: safePlaces,
          total: safePlaces.length,
        })
      },
    )
  })

  app.use((error, req, res, next) => {
    if (res.headersSent) return next(error)

    const status = error.status === 413 ? 413 : 500
    if (status === 413) {
      return res.status(status).send("A requisição excede o tamanho permitido.")
    }

    console.error("Erro inesperado na requisição:", error.message)
    return res.status(status).send("Não foi possível processar a requisição.")
  })

  return app
}

module.exports = { createApp }
