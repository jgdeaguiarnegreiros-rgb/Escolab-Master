const { createApp } = require("./app");
const { initializeDatabase, openDatabase } = require("./database/db");

const db = openDatabase((error) => {
  if (error) {
    console.error("Não foi possível abrir o banco de dados:", error.message);
    process.exitCode = 1;
    return;
  }

  initializeDatabase(db, (initializationError) => {
    if (initializationError) {
      console.error(
        "Banco de dados inválido ou indisponível:",
        initializationError.message,
      );
      return db.close(() => {
        process.exitCode = 1;
      });
    }

    const port = Number(process.env.PORT) || 3000;
    const server = createApp(db).listen(port, () => {
      console.log(`Ecoleta disponível em http://localhost:${port}`);
    });

    function shutdown() {
      server.close(() => {
        db.close((closeError) => {
          if (closeError) {
            console.error(
              "Erro ao fechar o banco de dados:",
              closeError.message,
            );
            process.exitCode = 1;
          }
        });
      });
    }

    process.once("SIGINT", shutdown);
    process.once("SIGTERM", shutdown);
  });
});
