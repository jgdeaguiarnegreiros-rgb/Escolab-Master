const path = require("node:path")
const sqlite3 = require("sqlite3").verbose()

function openDatabase(callback) {
  const databasePath = process.env.DATABASE_PATH || path.join(__dirname, "ecoleta.sqlite")
  return new sqlite3.Database(databasePath, callback)
}

function initializeDatabase(db, callback) {
  db.get("PRAGMA quick_check", (error, result) => {
    if (error) return callback(error)
    if (!result || result.quick_check !== "ok") {
      return callback(new Error("SQLite quick_check did not return ok."))
    }

    db.run(
      `CREATE TABLE IF NOT EXISTS places (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        image TEXT NOT NULL,
        name TEXT NOT NULL,
        address TEXT NOT NULL,
        address2 TEXT NOT NULL,
        state TEXT NOT NULL,
        city TEXT NOT NULL,
        items TEXT NOT NULL
      )`,
      callback,
    )
  })
}

module.exports = { initializeDatabase, openDatabase }
